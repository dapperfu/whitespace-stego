# optional password encryption logic
