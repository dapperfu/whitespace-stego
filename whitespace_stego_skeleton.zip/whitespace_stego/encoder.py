# encoder logic goes here
